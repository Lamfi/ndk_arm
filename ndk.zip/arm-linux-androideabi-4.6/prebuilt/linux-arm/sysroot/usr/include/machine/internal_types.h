/* $OpenBSD: internal_types.h,v 1.2 2004/05/06 15:53:39 drahn Exp $ */
/* Public domain */
#ifndef _ARM_INTERNAL_TYPES_H_
#define _ARM_INTERNAL_TYPES_H_

#ifdef __CHAR_UNSIGNED__
#define __machine_has_unsigned_chars
#endif

#endif
